package com.shai.calculaterapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private var currentInput = ""
    private var currentOperator = ""
    private var operand1 = 0.0
    private var operand2 = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numberButtons = listOf(
            btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9
        )

        numberButtons.forEach { button ->
            button.setOnClickListener { onNumberClick(button) }
        }

        btnPlus.setOnClickListener { onOperatorClick("+") }
        btnMinus.setOnClickListener { onOperatorClick("-") }
        btnMultiply.setOnClickListener { onOperatorClick("*") }
        btnDivide.setOnClickListener { onOperatorClick("/") }

        btnEqual.setOnClickListener { calculateResult() }
        btnClear.setOnClickListener { clearInput() }
    }

    private fun onNumberClick(button: Button) {
        currentInput += button.text
        inputEditText.text = currentInput
    }

    private fun onOperatorClick(operator: String) {
        if (currentInput.isNotEmpty()) {
            operand1 = currentInput.toDouble()
            currentInput = ""
            currentOperator = operator
        }
    }

    private fun calculateResult() {
        if (currentInput.isNotEmpty() && currentOperator.isNotEmpty()) {
            operand2 = currentInput.toDouble()

            val result = when (currentOperator) {
                "+" -> operand1 + operand2
                "-" -> operand1 - operand2
                "*" -> operand1 * operand2
                "/" -> if (operand2 != 0.0) operand1 / operand2 else Double.NaN
                else -> 0.0
            }

            inputEditText.text = if (result.isNaN()) "Error" else result.toString()
            currentInput = ""
            currentOperator = ""
            operand1 = 0.0
            operand2 = 0.0
        }
    }

    private fun clearInput() {
        currentInput = ""
        currentOperator = ""
        operand1 = 0.0
        operand2 = 0.0
        inputEditText.text = ""
    }
}
